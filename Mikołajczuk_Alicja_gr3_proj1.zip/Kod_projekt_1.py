# -*- coding: utf-8 -*-
"""
Created on Tue Mar 26 10:32:03 2019

@author: Alicja
"""

import sys 
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLineEdit, QLabel, QGridLayout, QColorDialog

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import math

class AppWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.title ='Wyznaczenie punktu przecięcia dwóch odcinków'
        self.initInterface()
        self.initWidgets()
        
    def initInterface(self):
        self.setWindowTitle(self.title)
        self.setGeometry(700,200,700,800)
        self.show()
        
    def initWidgets(self):
#definiowanie przycisków
        btn = QPushButton("Oblicz", self)
        btnZapis = QPushButton("zapisz", self)
        btnCol = QPushButton("rysuj", self)
        btnClear = QPushButton("wyczysc",self)
        
#opis pól w aplikacji
        XaLabel = QLabel("Xa", self)
        YaLabel = QLabel("Ya", self)
        XbLabel = QLabel("Xb", self)
        YbLabel = QLabel("Yb", self)
        XcLabel = QLabel("Xc", self)
        YcLabel = QLabel("Yc", self)
        XdLabel = QLabel("Xd", self)
        YdLabel = QLabel("Yd", self)
        
        XpLabel = QLabel("Xp", self)
        YpLabel = QLabel("Yp", self)
        
        UkladLabel = QLabel("Położenie punktu P", self)
        PAB = QLabel("Położenie punktu P względem AB", self)
        PCD = QLabel("Położenie punktu P względem CD", self)
        AzAB = QLabel("Azymut AB", self)
        AzCD = QLabel("Azymut CD",self)
        dAB = QLabel("Długosc odcinka AB",self)
        dCD = QLabel("Długosc odcinka CD",self)
        
#okienka edycji sluzace do wpisania wspolrzednych ktore beda pobierane
        self.xaEdit = QLineEdit()
        self.yaEdit = QLineEdit()
        self.xbEdit = QLineEdit()
        self.ybEdit = QLineEdit()
        self.xcEdit = QLineEdit()
        self.ycEdit = QLineEdit()
        self.xdEdit = QLineEdit()
        self.ydEdit = QLineEdit()
#okienka do zapisu wynikow
        self.xpWynik = QLabel("",self)
        self.ypWynik = QLabel("",self)
        self.uklad = QLabel("",self)
        self.PAB = QLabel("",self)
        self.PCD = QLabel("",self)
        self.AzAB = QLabel("",self)
        self.AzCD = QLabel("",self)
        self.dAB = QLabel("",self)
        self.dCD = QLabel("",self)
        
        
#wykres
        self.figure = plt.figure()
        self.canvas = FigureCanvas(self.figure)
#umiejscowienie pól w aplikacji
        grid = QGridLayout()
        
        grid.addWidget(XaLabel,0,0)
        grid.addWidget(self.xaEdit,0,1)
        
        grid.addWidget(YaLabel,1,0)
        grid.addWidget(self.yaEdit,1,1)
        
        grid.addWidget(XbLabel,2,0)
        grid.addWidget(self.xbEdit,2,1)
        
        grid.addWidget(YbLabel,3,0)
        grid.addWidget(self.ybEdit,3,1)
        
        grid.addWidget(XcLabel,4,0)
        grid.addWidget(self.xcEdit,4,1)
        
        grid.addWidget(YcLabel,5,0)
        grid.addWidget(self.ycEdit,5,1)
        
        grid.addWidget(XdLabel,6,0)
        grid.addWidget(self.xdEdit,6,1)
        
        grid.addWidget(YdLabel,7,0)
        grid.addWidget(self.ydEdit,7,1)
        
        grid.addWidget(btn,8,0,1,2)
        grid.addWidget(btnZapis,9,0,1,2)
        grid.addWidget(btnCol, 10,0,1,2)
        grid.addWidget(btnClear, 11, 0,1,2)
        
        grid.addWidget(XpLabel,12,0)
        grid.addWidget(self.xpWynik,12,1)
        
        grid.addWidget(YpLabel,13,0)
        grid.addWidget(self.ypWynik,13,1)
        
        grid.addWidget(UkladLabel,14,0)
        grid.addWidget(self.uklad,15,0)
        grid.addWidget(PAB,16,0)
        grid.addWidget(self.PAB,17,0)
        grid.addWidget(PCD,18,0)
        grid.addWidget(self.PCD,19,0)
        
        grid.addWidget(AzAB,20,0)
        grid.addWidget(self.AzAB,20,1)
        grid.addWidget(AzCD,21,0)
        grid.addWidget(self.AzCD,21,1)
        grid.addWidget(dAB,22,0)
        grid.addWidget(self.dAB,22,1)
        grid.addWidget(dCD,23,0)
        grid.addWidget(self.dCD,23,1)
        
        grid.addWidget(self.canvas,1,2,-1,-1)
        
        
        
       
        
        
        self.setLayout(grid)
#aktywacja puschbuttonow poprzez klikniecie
        btn.clicked.connect(self.oblicz)
        btnZapis.clicked.connect(self.zapis)
        btnCol.clicked.connect(self.zmienkolor)
        btnClear.clicked.connect(self.wyczysc)
        
#zmiana koloru wykresu
    def zmienkolor(self):
        color = QColorDialog.getColor()
        if color.isValid():
            print(color.name())
            self.rysuj(col=color.name())
        
    def oblicz(self):
#sprawdzenie wpisanych wartosci oraz przypisanie do nich zmiennych
        Xa = self.sprawdzwartosc(self.xaEdit)
        Ya = self.sprawdzwartosc(self.yaEdit)
        Xb = self.sprawdzwartosc(self.xbEdit)
        Yb = self.sprawdzwartosc(self.ybEdit)
        Xc = self.sprawdzwartosc(self.xcEdit)
        Yc = self.sprawdzwartosc(self.ycEdit)
        Xd = self.sprawdzwartosc(self.xdEdit)
        Yd = self.sprawdzwartosc(self.ydEdit)
   
#obliczenie azymutów      
        PI = math.pi
        Az = 0 
        Az1 = '%.3f' % Az
        self.AzAB.setText(str(Az1))
        dY = Yb-Ya
        dX = Xb-Xa
        if dX > 0:
            Az = 90 - math.atan( dY / dX ) * 180 / PI
            Az1 = '%.3f' % Az
            self.AzAB.setText(str(Az1))
        elif dX < 0:
            Az = 270 - math.atan( dY / dX )* 180 / PI
            Az1 = '%.3f' % Az
            self.AzAB.setText(str(Az1))
        elif dY < 0:
            Az = 180
            Az1 = '%.3f' % Az
            self.AzAB.setText(str(Az1))
            
        Az1 = 0 
        Az2 = '%.3f' % Az1
        self.AzCD.setText(str(Az2))
        dY1 = Yd-Yc
        dX1 = Xd-Xc
        if dX > 0:
            Az1 = 90 - math.atan( dY1 / dX1 ) * 180 / PI
            Az2 = '%.3f' % Az1
            self.AzCD.setText(str(Az2))
        elif dX < 0:
            Az1 = 270 - math.atan( dY1 / dX1 )* 180 / PI
            Az2 = '%.3f' % Az1
            self.AzCD.setText(str(Az2))
        elif dY < 0:
            Az1 = 180
            Az2 = '%.3f' % Az1
            self.AzCD.setText(str(Az2))
            
#obliczenie długosci odcinkow
        dab = math.sqrt(dY**2 + dX**2)
        DAB = '%.3f' % dab
        self.dAB.setText(str(DAB))
        
        dcd = math.sqrt(dY1**2 + dX1**2)
        DCD = '%.3f' % dcd
        self.dCD.setText(str(DCD))
        
        
        #petla do obliczenia wspolrzednych oraz okreslenia polozenia punktu P
        a=1
        while a==1:
            
            if  ((Xb-Xa)*(Yd-Yc)-(Yb-Ya)*(Xd-Xc))==0:
                self.uklad.setText('-odcinki są równoległe')
            
            elif ((Xb-Xa)*(Yd-Yc)-(Yb-Ya)*(Xd-Xc))!=0:
                t1 = ((Xc-Xa)*(Yd-Yc)-(Yc-Ya)*(Xd-Xc))/((Xb-Xa)*(Yd-Yc)-(Yb-Ya)*(Xd-Xc))
                t2 = ((Xc-Xa)*(Yb-Ya)-(Yc-Ya)*(Xb-Xa))/((Xb-Xa)*(Yd-Yc)-(Yb-Ya)*(Xd-Xc))
                print(t1)
                print(t2)
                
                if t1>=0 and t1<=1 and t2>=0 and t2<=1:
                    self.uklad.setText('-punkt należy do obu odcinków')
                    xP1 = Xa + t1*(Xb-Xa)
                    yP1 = Ya + t1*(Yb-Ya)
                    xP2 = Xa + t2*(Xd-Xc)
                    yP2 = Ya + t2*(Yd-Yc)
                    xP = '%.3f' % xP1
                    self.xpWynik.setText(str(xP))
                    yP = '%.3f' % yP1
                    self.ypWynik.setText(str(yP))
                    
                elif (t1<0 or t1>1) and (t2<0 or t2>1):
                    self.uklad.setText('-punkt leży na przedłużeniu obu odcinków')
                    xP1 = Xa + t1*(Xb-Xa)
                    yP1 = Ya + t1*(Yb-Ya)
                    xP2 = Xa + t2*(Xd-Xc)
                    yP2 = Ya + t2*(Yd-Yc)
                    xP = '%.3f' % xP1
                    self.xpWynik.setText(str(xP))
                    yP = '%.3f' % yP1
                    self.ypWynik.setText(str(yP))
                    
                else:
                    self.uklad.setText('-punkt leży na przedłużeniu jednego z odcinków')
                    xP1 = Xa + t1*(Xb-Xa)
                    yP1 = Ya + t1*(Yb-Ya)
                    xP2 = Xa + t2*(Xd-Xc)
                    yP2 = Ya + t2*(Yd-Yc)
                    xP = '%.3f' % xP1
                    self.xpWynik.setText(str(xP))
                    yP = '%.3f' % yP1
                    self.ypWynik.setText(str(yP))
                break
        #Po ktorej stronie odcinka lezy punkt P
        detABP = Xa*Yb+Xb*yP1+xP1*Ya-xP1*Yb-Xa*yP1-Xb*Ya
        if detABP>0:
            self.PAB.setText('-punkt leży po prawej stronie odcinka')
        if detABP<0:
            self.PAB.setText('-punkt leży po lewej stronie odcinka')
        if detABP==0:
            self.PAB.setText('-punkty są współliniowe')
        detCDP = Xc*Yd+Xd*yP1+xP1*Yc-xP1*Yd-Xc*yP1-Xd*Yc
        if detCDP>0:
            self.PCD.setText('-punkt leży po prawej stronie odcinka')
        if detCDP<0:
            self.PCD.setText('-punkt leży po lewej stronie odcinka')
        if detCDP==0:
            self.PCD.setText('-punkty są współliniowe')
            
        
        
       
                    
       
        
                
    #zapisanie wyniku xP yP do pliku tekstowego  
    def zapis(self):
        p1=open('Projekt_1_xPyP.txt',"w+")
        p1.write(55*'-')
        p1.write("\n|{0:^26}|{1:^26}|\n".format("Xp","Yp"))
        p1.write("\n|{0:^25.4f}m|{1:^25.4f}m|\n".format(self.sprawdzwartosc(self.xpWynik),self.sprawdzwartosc(self.ypWynik)))
        p1.write(55*'-')
        p1.close()
        
    def rysujdomyslnie(self):
        self.rysuj()
    #definicja funkcji rysującej
    def rysuj(self, col='red'):
        
        Xa = self.sprawdzwartosc(self.xaEdit)
        Ya = self.sprawdzwartosc(self.yaEdit)
        Xb = self.sprawdzwartosc(self.xbEdit)
        Yb = self.sprawdzwartosc(self.ybEdit)
        Xc = self.sprawdzwartosc(self.xcEdit)
        Yc = self.sprawdzwartosc(self.ycEdit)
        Xd = self.sprawdzwartosc(self.xdEdit)
        Yd = self.sprawdzwartosc(self.ydEdit)
        xP1 = self.sprawdzwartosc(self.xpWynik)
        yP1 = self.sprawdzwartosc(self.ypWynik)
        A = [Xa,Ya]
        B = [Xb, Yb]
        C = [Xc, Yc]
        D = [Xd, Yd]
        
        if (Xa is not None) and (Ya is not None) and (Xb is not None) and (Yb is not None) and (Xc is not None) and (Yc is not None) and (Xd is not None) and (Yd is not None):
            self.figure.clear()
            Xab = [Xa,Xb]
            Yab = [Ya, Yb]
            Xcd = [Xc, Xd]
            Ycd = [Yc, Yd]
            ax = self.figure.add_subplot(111)
            a = ax.plot(Xab,Yab,color=col, marker='o')
            b = ax.plot(Xcd,Ycd,color=col, marker='o')
            c = ax.plot(xP1,yP1,color='red', marker='o')
            #etykiety do punktow
            plt.annotate('P', xy=(xP1,yP1), xytext=(xP1+0.01,yP1+0.01))
            plt.annotate('A', xy=(Xa,Ya), xytext=(Xa+0.01,Ya+0.01))
            plt.annotate('B', xy=(Xb,Yb), xytext=(Xb+0.01,Yb+0.01))
            plt.annotate('C', xy=(Xc,Yc), xytext=(Xc+0.01,Yc+0.01))
            plt.annotate('D', xy=(Xd,Yd), xytext=(Xd+0.01,Yd+0.01))
            
            
            
            
            
        
            
            
            self.canvas.draw()
        
    #funkcja sprawdzająca poprawnosc wpisanych wspolrzednych
    def sprawdzwartosc(self,element):
        if element .text().lstrip('-').replace('.','',1).isdigit():
            return float(element.text())
        else:
            element.setFocus()
            return None
    #funkcja czyszczaca pola
    def wyczysc(self):
        self.xaEdit.clear()
        self.yaEdit.clear()
        self.xbEdit.clear()
        self.ybEdit.clear()
        self.xcEdit.clear()
        self.ycEdit.clear()
        self.xdEdit.clear()
        self.ydEdit.clear()
        self.xpWynik.clear()
        self.ypWynik.clear()
        self.uklad.clear()
        self.PAB.clear()
        self.PCD.clear()
        self.AzAB.clear()
        self.AzCD.clear()
        self.dAB.clear()
        self.dCD.clear()
        
        
        
        
    
def main():
    app = QApplication(sys.argv)
    window = AppWindow()
    app.exec_()
    
if __name__ == "__main__":
    main()
    
    
    

